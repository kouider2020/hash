"""Session Initiation Protocol."""

from pypacker.layer567.http import HTTP


class SIP(HTTP):
	pass
